<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Printis, Your Online Printing Solution </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/aos.min.css">
    <link rel="stylesheet" href="css/hamburgers/hamburgers.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/animsition.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="bg-ic.png">
    <style type="text/css">
      .img-detail{
        float : left;
        margin-right: 5%;
      }
      .count_me{
        text-align: left; 
      }

      #order_detail{
        float: left;
      }
      #order_detail p {
        padding: -5% -5% -5% -5%;
      }
      #gmaps{
        float: left;
      }
    </style>
  </head>
  <body>
  
  <div class="js-animsition animsition" data-animsition-in-class="fade-in" data-animsition-out-class="fade-out">

    <header class="templateux-navbar" data-aos="fade-down">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-3 col-3"><div class="site-logo"><a href="index.php" class="animsition-link">PrintIs</a></div></div>
          <div class="col-sm-9 col-9 text-right">

            <button class="hamburger hamburger--spin toggle-menu ml-auto js-toggle-menu" type="button">
              <span class="hamburger-box">
                <span class="hamburger-inner"></span>
              </span>
            </button>  

            <nav class="templateux-menu js-templateux-menu" role="navigation">
              <ul class="list-unstyled">
                <li><a href="index.php" class="animsition-link">Home</a></li>
                <li><a href="index.php" class="animsition-link">Profile</a></li>
                <li><a href="index.php" class="animsition-link">Gallery</a></li>
                <li><a href="index.php" class="animsition-link">Contact</a></li>
                <li><a href="login.php" class="animsition-link">User<i class="fa fa-fw fa-caret"></i></a></li>
              </ul>
            </nav>  
          </div>
        </div>
      </div>
    </header>

    <!-- END templateux-navbar -->
    <section class="templateux-hero">
      <div class="container">
        <div class="row align-items-center justify-content-center intro">
          <div class="col-md-12">
            <div class="col-md-12 text-center" >
              <img src="images/4.jpeg" alt="" class="img-detail" width="200px" height="200px" style="float: left;">
              <div class="count_me">
                <p><b>Nama Mitra :</b> Prima Printing</p>
                <p><b>Lokasi : </b> Jl. Mojopahit No 10</p>
                <p><b>Rating : 5</b></p>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
              </div>
            </div>
            
            <div class="col-md-6" id="gmaps">
              <p>Lokasi</p>
              <img src="images/gmaps.jpg" alt="" width="400px" height="200px" style="float: left;">
            </div>
            <div class="col-md-4" id="order_detail">
              <p>Order Print File (.pdf)</p>
              <button type="button" class="btn btn-default">Choose</button> <span>No File</span>
              <p></p>
              <textarea></textarea>
              <p></p>
              <button type="button" class="btn btn-sm btn-success" data-target="#exampleModal" data-toggle="modal" onclick="detailsmodal">OK</button>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- END templateux-hero -->
    
    <footer class="templateux-footer">
      <div class="container-fluid">
        
            <p class="text-center">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Homepage Footer
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
       
      </div>
    </footer>

  </div>
<!-- 
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-isi="Web Master">Paket 1</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-isi="Desain Grafis">Paket 2</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-isi="Digital Marketing">Paket 3</button> -->

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" style="text-align: center;">Pembayaran </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form style="text-align: center;">
            <div class="form-group">
              <label for="recipient-name" class="form-control-label"><b>Fee:</b>  Rp 10.000</label>
            </div>
            <div class="form-group">
              <label for="message-text" class="form-control-label"><b>Ongkir:</b> Rp 10.000</label>
            </div>
            <div class="form-group">
              <label for="message-text" class="form-control-label"><b>Print:</b> Rp 20.000</label>
            </div>
            <div class="form-group">
              <label for="message-text" class="form-control-label"><b>Total: Rp 40.000</b></label>
            </div>
          </form>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="text-align: center;">E-Cash</button>
          <button type="button" class="btn btn-success">Tunai</button>
        </div>
      </div>
    </div>
  </div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
<script>
  $('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 
    var recipient = button.data('isi')
    var modal = $(this)

    modal.find('.modal-body input').val(recipient)
  })
</script>

  
  <script src="js/scripts-all.js"></script>
  <script src="js/main.js"></script>
  
  </body>
</html>