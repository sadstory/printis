<!DOCTYPE html>
<html lang="en">

<head>

    <?php include"head.php";?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <?php include'top-nav.php';?>
            <!-- Top Menu Items -->
            <?php include'top-menu.php';?>


            <?php include'nav.php';?>
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Mitra
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.php">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-users"></i> Data Mitra
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                   
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <h2>Data Mitra</h2>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Mitra</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <th>No Telpon</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>CV Makmur Jaya</td>
                                        <td>makmur_jaya</td>
                                        <td>password</td>
                                        <td>081749798394</td>
                                        <td><a href="#"><i class="fa fa-fw fa-edit"></i></a><a href="#"><i class="fa fa-fw fa-trash"></i></a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
                <!-- /.row -->

                <?php include'chart.php';?>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
